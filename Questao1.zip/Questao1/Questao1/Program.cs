﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Arthur Felipe Lopes Silva
// 12311ETE013

namespace Questao1
{
    static class Questao1
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Digite o nome completo:");
            string nomeCompleto = Console.ReadLine();

            NomeProprio nome = new NomeProprio(nomeCompleto);

            nome.ImprimeNomePaper();

            Console.ReadKey();
        }
    }
}